IronBuddy: Workout Tracker press kit

You are welcome to use the descriptions, the app icon and the screenshots in articles, reviews, videos and listings about IronBuddy.
The latest version of this kit is at https://workout.ironbuddy.fit/press/

FACT SHEET

Name: IronBuddy: Workout Tracker
Developer: IronBuddy
What it is: An offline workout tracker and gym log app
Platform: Android, on Google Play. Not available on iPhone yet.
Released: 30 September 2026
Price: Free to download with a 7-day free trial. After the trial, a one-time in-app purchase is required to keep logging and editing. No subscription. Google Play shows the price in local currency.
Ads and account: No ads, no account and no sign-in
Data: Stored on the phone and not sent to IronBuddy servers
Category: Health & Fitness
Language: English
Android package: com.ironbuddy.app
Website: https://workout.ironbuddy.fit
Google Play: https://play.google.com/store/apps/details?id=com.ironbuddy.app
Press contact: https://workout.ironbuddy.fit/contact/

DESCRIPTIONS

One sentence (19 words):
IronBuddy is an offline workout tracker and gym log for Android, with no account, no ads and no subscription.

Short (56 words):
IronBuddy is an offline workout tracker and gym log app for Android. Lifters use it to plan training splits, log sets, reps and weight, and track progressive overload with charts of training volume and 1RM (one-rep max), calculated with the Epley formula. It needs no account, shows no ads, and keeps workout data on the phone.

Long (115 words):
IronBuddy is an offline workout tracker and gym log for Android, built for lifters who want to own their training data. It comes with 10 split templates, including Push Pull Legs, Upper Lower and Full Body, and logs every set with reps, weight, notes and techniques such as drop sets and supersets. Charts show training volume and 1RM for each exercise, alongside body weight and body fat percentage, and an exercise library of more than 800 exercises includes demonstrations. IronBuddy works without an internet connection, needs no account and has no ads. It is free to download with a 7-day free trial; after that, a one-time purchase unlocks the full app. There is no subscription.

KEY FEATURES

- Offline workout logging with sets, reps, weight and notes
- Training splits and templates (Push Pull Legs, Upper Lower, Full Body, custom)
- 1RM, best weight and training volume charts
- Muscles worked body map and weekly Muscle Balance
- Workout summary with changes against last time and personal records
- Body weight and body fat percentage tracking
- Exercise library with 800+ exercises and demonstrations
- JSON backup and export (full version), and a PDF export of the active split
- Customizable Home: widgets you arrange and resize (full version), and your choice of calendar look
- Share cards: workouts, records and charts as images (full version)
- Light, dark or system theme; accent colors (full version)
- No account, no ads and no subscription

BRAND

- Write the name as IronBuddy: one word, with a capital I and a capital B.
- Use the app icon as supplied. Please do not recolour, stretch or crop it, or add effects.
- The screenshots show the app as it was on 13 October 2026.
- Colours: Lime #B7FF2A, Navy #050B14

FILES

app-icon/ironbuddy-app-icon-1024.png  (App icon, 1024 x 1024 PNG)
screenshots/ironbuddy-workout-tracker-home.png  (Dashboard, 720 x 1516 PNG)
screenshots/ironbuddy-workout-log.png  (Workout Logging, 720 x 1516 PNG)
screenshots/ironbuddy-training-splits.png  (Training Splits, 720 x 1516 PNG)
screenshots/ironbuddy-training-volume.png  (Training Volume, 720 x 1516 PNG)
screenshots/ironbuddy-estimated-1rm-chart.png  (1RM Chart, 720 x 1516 PNG)
screenshots/ironbuddy-body-weight-tracker.png  (Body Metrics, 720 x 1516 PNG)
screenshots/ironbuddy-exercise-library.png  (Exercise Library, 720 x 1516 PNG)
screenshots/ironbuddy-muscle-balance.png  (Muscle Balance, 720 x 1516 PNG)
screenshots/ironbuddy-workout-summary.png  (Workout Summary, 720 x 1516 PNG)
screenshots/ironbuddy-share-card.png  (Share Cards, 720 x 1516 PNG)
screenshots/ironbuddy-exercise-page.png  (Exercise Page, 720 x 1516 PNG)
screenshots/ironbuddy-customizable-home.png  (Customizable Home, 720 x 1516 PNG)
screenshots/ironbuddy-accent-colors.png  (Accent Colors, 720 x 1516 PNG)
screenshots/ironbuddy-offline-data.png  (Your Data, 720 x 1516 PNG)
